        # Yordamchi AI — Telegram kontekstli yordamchi bot

"
        Bu loyiha Telegram uchun kontekstli AI yordamchi bot. Loyihani Railway.com ga yuklab, .env ga o'z tokenlaringizni qo'yib deploy qilishingiz mumkin.

"
        ## Qanday ishlatish

1. `TG_BOT_TOKEN` va `OPENAI_API_KEY` ni `.env` faylga qo'yish ('.env.example' ni nusxa oling).

2. Lokalda sinov uchun:

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env  # va .env ni tahrirlab tokenlarni qo'ying
python bot.py
```

3. Railway ga joylashtirish:
   - Railway ga kirib yangi project yarating.
   - ZIP faylni upload qiling yoki GitHub repoga push qiling.
   - Environment variables bo'limiga `TG_BOT_TOKEN` va `OPENAI_API_KEY` ni qo'shing.
   - Deploy qiling.

## Xususiyatlar
- Kontekstli suhbat (SQLite orqali foydalanuvchi xabarlarini saqlaydi).
- `/clear` komandi bilan suhbat tarixini o'chirish mumkin.

## Maxfiylik
Tokenlaringizni hech qachon ochiq e'lon qilmang. Bu loyiha `.env` orqali tokenlarni o'rnatishni talab qiladi.
