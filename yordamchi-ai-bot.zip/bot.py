        import os
        import logging
        import sqlite3
        from datetime import datetime
        from telegram import Update
        from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
        import openai
        from dotenv import load_dotenv

        # Load environment variables from .env (Railway will set env vars)
        load_dotenv()

        TG_BOT_TOKEN = os.getenv("TG_BOT_TOKEN")
        OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

        if not TG_BOT_TOKEN or not OPENAI_API_KEY:
            raise RuntimeError("TG_BOT_TOKEN and OPENAI_API_KEY must be set in environment variables. See .env.example")

        openai.api_key = OPENAI_API_KEY

        logging.basicConfig(level=logging.INFO)
        logger = logging.getLogger(__name__)

        # SQLite DB for conversation memory (file will be created next to the bot file)
        DB_PATH = os.path.join(os.path.dirname(__file__), "conversations.db")

        def init_db():
            conn = sqlite3.connect(DB_PATH, check_same_thread=False)
            cur = conn.cursor()
            cur.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                role TEXT NOT NULL,          -- 'user' or 'assistant' or 'system'
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            """)
            conn.commit()
            return conn

        db_conn = init_db()

        def save_message(user_id: int, role: str, content: str):
            cur = db_conn.cursor()
            cur.execute(
                "INSERT INTO messages (user_id, role, content, created_at) VALUES (?, ?, ?, ?)",
                (user_id, role, content, datetime.utcnow().isoformat())
            )
            db_conn.commit()

        def load_recent_messages(user_id: int, limit: int = 8):
            cur = db_conn.cursor()
            cur.execute(
                "SELECT role, content FROM messages WHERE user_id = ? ORDER BY id DESC LIMIT ?",
                (user_id, limit)
            )
            rows = cur.fetchall()
            # rows are newest first; reverse to chronological order
            rows.reverse()
            return [{"role": r[0], "content": r[1]} for r in rows]

        # Basic system prompt in Uzbek
        SYSTEM_PROMPT = (
            "Siz O'zbek tilida foydalanuvchiga do'stona, aniq va yordamchi javoblar beruvchi AI yordamchisiz. "
            "Javoblaringiz qisqa va tushunarli bo'lsin. Agar foydalanuvchi shaxsiy yoki xavfli ma'lumot yuborsa, "
            "uning maxfiyligini eslatib, ochiq ma'lumotlardan foydalaning."
        )

        async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
            await update.message.reply_text(
                "👋 Salom! Men *Yordamchi AI* botman. Siz bilan muloqotni davom ettiraman va oldingi xabarlaringizni eslab qolaman.

"
                "✳️ /help — yordam
✳️ /clear — suhbat tarixini o‘chirish",
                parse_mode='Markdown'
            )

        async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
            await update.message.reply_text(
                "Savolingizni yozing — men avvalgi xabarlaringizni eslab, kontekst asosida javob beraman.
"
                "Agar tarixni o‘chirmoqchi bo‘lsangiz /clear buyrug‘idan foydalaning."
            )

        async def clear_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
            user_id = update.effective_user.id
            cur = db_conn.cursor()
            cur.execute("DELETE FROM messages WHERE user_id = ?", (user_id,))
            db_conn.commit()
            await update.message.reply_text("✅ Suhbat tarixingiz o'chirildi. Yangi suhbat boshlash mumkin.")

        async def ai_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
            user_id = update.effective_user.id
            user_text = update.message.text.strip()
            if not user_text:
                await update.message.reply_text("Iltimos, savolingizni yozing.")
                return

            # Save user message
            save_message(user_id, "user", user_text)

            # Build context: system prompt + recent messages (limit token budget roughly)
            recent = load_recent_messages(user_id, limit=10)  # include both user and assistant messages
            messages = [{"role": "system", "content": SYSTEM_PROMPT}] + recent + [{"role": "user", "content": user_text}]

            # Call OpenAI ChatCompletion (gpt-3.5-turbo used by default)
            try:
                resp = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=messages,
                    max_tokens=512,
                    temperature=0.6,
                    n=1
                )
                answer = resp["choices"][0]["message"]["content"].strip()
            except Exception as e:
                logger.exception("OpenAI request failed")
                await update.message.reply_text("Uzr, AI bilan bog'lanishda xatolik yuz berdi. Keyinroq urinib ko'ring.")
                return

            # Save assistant message in DB for context
            save_message(user_id, "assistant", answer)

            # Reply to user (split if too long for Telegram)
            MAX_LEN = 4000
            if len(answer) <= MAX_LEN:
                await update.message.reply_text(answer)
            else:
                # split into chunks
                for i in range(0, len(answer), MAX_LEN):
                    await update.message.reply_text(answer[i:i+MAX_LEN])

        def main():
            app = ApplicationBuilder().token(TG_BOT_TOKEN).build()
            app.add_handler(CommandHandler("start", start))
            app.add_handler(CommandHandler("help", help_cmd))
            app.add_handler(CommandHandler("clear", clear_cmd))
            app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, ai_reply))
            logger.info("Bot ishga tushmoqda...")
            app.run_polling()

        if __name__ == '__main__':
            main()
